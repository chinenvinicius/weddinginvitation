/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Parent, Sponsor, WeddingPartyList, EntourageKidsAndBearers, ProgramRoles } from './types';

export const groomParents: Parent[] = [
  { name: "Decio Yochimasa Chinen" },
  { name: "Terezina Chinen" }
];

export const brideParents: Parent[] = [
  { name: "Hermie C. Goyo" },
  { name: "Bernardita S. Goyo" }
];

export const principalSponsors: Sponsor[] = [
  { number: 1, name: "Mr. and Mrs. Peter Salvan" },
  { number: 2, name: "Mr. and Mrs. Jerry Cuyos" },
  { number: 3, name: "Mr. and Mrs. Jonel Seraspe" },
  { number: 4, name: "Mr. and Mrs. Donald Montero" },
  { number: 5, name: "Mr. and Mrs. Eleazar Illustrisimo" },
  { number: 6, name: "Mr. and Mrs. Winnie Berago" },
  { number: 7, name: "Mr. and Mrs. Daniel Barilla" },
  { number: 8, name: "Mr. and Mrs. Al Laude" },
  { number: 9, name: "Mr. and Mrs. Jose Abelita" },
  { number: 10, name: "Mr. Juseven Austero and Mrs. Joey Amoguis" },
  { number: 11, name: "Mr. and Mrs. Hiromitsu Nakamura" },
  { number: 12, name: "Mr. and Mrs. Rhoen Shane P. Catolico" },
  { number: 13, name: "Mr. and Mrs. Emeliano Jr. Gultiano" },
  { number: 14, name: "Mr. and Mrs. Concordio Apa-ap" },
  { number: 15, name: "Mr. and Mrs. Gerardo Soejima" },
  { number: 16, name: "Mr. and Mrs. Melzar Dagangon" },
  { number: 17, name: "Mr. and Mrs. Roxie Pido" },
  { number: 18, name: "Mr. and Mrs. Robert Goyo" },
  { number: 19, name: "Mr. and Mrs. Samuel Frigillano" },
  { number: 20, name: "Mr. and Mrs. Johnny Tagsa" },
  { number: 21, name: "Mr. and Mrs. Raul Tayabas" },
  { number: 22, name: "Mr. and Mrs. Joel Damasco" },
  { number: 23, name: "Mr. and Mrs. Yajiro Soejima SR." },
  { number: 24, name: "Mr. and Mrs. Genithon Conales" },
  { number: 25, name: "Mr. and Mrs. Famelito Umapas" },
  { number: 26, name: "Mr. and Mrs. Lito Orozco" },
  { number: 27, name: "Mr. and Mrs. Marlon Dobluis" },
  { number: 28, name: "Mr. and Mrs. Samuel Sanchez" }
];

export const secondarySponsors = {
  matronOfHonor: "Geraldine S. Librea",
  bestMan: "Wendell B. Librea"
};

export const weddingParty: WeddingPartyList = {
  bridesmaids: [
    "Beatrice Okada",
    "Caroline Natsumy Chinen",
    "Maricel Soejima",
    "April Mae Perez",
    "Kenneth Joy Soejima",
    "Sheena Angelika Soejima",
    "Sheena Angela Soejima",
    "Sheena Claire Soejima"
  ],
  groomsmen: [
    "Cleverson Okada",
    "Vitor Felipe Chinen",
    "Yajiro Soejima",
    "Darryl Cuyos",
    "Donuel Soejima",
    "EJ Seraspe",
    "Zoe Jigs Montero",
    "Ojie Cuyos"
  ],
  flowerMaidens: [
    "Krisha Mae Vasquez",
    "Princess Jheuel Soejima",
    "Alyajinna Soejima",
    "Vina Aisha Yuri Madamba",
    "Joana Yukari Okada",
    "Rebeca Yurika Okada"
  ]
};

export const childEntourageAndBearers: EntourageKidsAndBearers = {
  flowerGirls: [
    "Aiko Arendain",
    "Freyjah Myrrh Sagarino",
    "Haruka Canada",
    "Akeisha Vasquez",
    "Sofia Chinen"
  ],
  escorts: [
    "Yuhei Sagarino",
    "Pedro Minato Okada",
    "Jirou Bitgue",
    "Yuie Ichiro Soejima",
    "Kaizen Zion Soejima"
  ],
  littleBride: "Sheena Cassandra Soejima",
  littleGroom: "Erick Chinen",
  ringBearer: "Sicq Ephraim Lajera",
  bibleBearer: "Akio Arendain",
  bannerBearers: [
    "Felipe Mitsuki Okada",
    "Zaina Rei Bitgue",
    "Aika Arendain"
  ],
  candleLighters: "Mr. and Mrs. Emannuel Soejima"
};

export const programRoles: ProgramRoles = {
  officiatingMinister: "Ptr. Guenjie Imayuki",
  emcee: "Melchie U. Salvan",
  singer: "Shaira Delos Reyes",
  programCoordinator: "Mary Jane O. Nakano",
  usherettes: [
    "Shaina Sweet Delos Reyes",
    "Ivy Ababa",
    "Vem Pasco"
  ]
};

export const dressCodeColorsGown = [
  { name: "Cream White", hex: "#EDEEE9" },
  { name: "Pale Pearl Sage", hex: "#DDE5D6" },
  { name: "Soft Sage", hex: "#ADC2B1" },
  { name: "Olive Sage", hex: "#7E927F" },
  { name: "Forest Green", hex: "#3A4F3D" }
];

export const dressCodeColorsSuit = [
  { name: "Deep Plum Wine", hex: "#3D171A" },
  { name: "Rich Burgundy", hex: "#591F26" },
  { name: "Garnet Maroon", hex: "#4C1C24" },
  { name: "Plum Berry", hex: "#2E1116" },
  { name: "Dark Velvet Raisin", hex: "#1C0B0E" }
];

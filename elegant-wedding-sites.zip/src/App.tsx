/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useRef } from 'react';
import { motion } from 'motion/react';
import { Heart, Sparkles, MapPin, Calendar, Clock } from 'lucide-react';

// Components
import BackgroundMusic from './components/BackgroundMusic';
import InvitationCover from './components/InvitationCover';
import SponsorsSec from './components/SponsorsSec';
import WeddingParty from './components/WeddingParty';
import CeremonyRoles from './components/CeremonyRoles';
import DetailsSec from './components/DetailsSec';

export default function App() {
  // References to scroll down from the hero CTA
  const detailsRef = useRef<HTMLDivElement | null>(null);

  const scrollToDetails = () => {
    detailsRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div id="wedding-invite-app" className="min-h-screen bg-[#FDFDFB] text-sage-900 font-sans selection:bg-sage-200 selection:text-sage-800 antialiased overflow-x-hidden relative">
      
      {/* Full App Subtle Watercolor Paper Texture Background Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-repeat pointer-events-none opacity-[0.05] mix-blend-multiply z-0" 
        style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&q=80&w=1600")' }} 
      />

      {/* 1. Header / Navigation Initials Indicator (Centered Minimalist Aesthetic, No heavy sidebars/menus) */}
      <header className="fixed top-0 inset-x-0 h-16 bg-white/40 backdrop-blur-md z-45 border-b border-sage-150/20 flex items-center justify-between px-6 sm:px-12 select-none">
        <span className="font-montserrat text-[10px] tracking-[0.3em] font-bold text-sage-600 uppercase">
          Vinicius & Trish
        </span>
        <div className="flex items-center gap-1">
          <span className="font-script text-3xl text-sage-800">V</span>
          <Heart className="w-3 h-3 text-sage-400 fill-sage-300 animate-pulse" />
          <span className="font-script text-3xl text-sage-800">T</span>
        </div>
        <span className="font-montserrat text-[9px] tracking-widest text-[#A38E7E] font-medium">
          08.12.26
        </span>
      </header>

      {/* Decorative Padding Top to account for floating header */}
      <div className="h-16" />

      {/* 2. Invitation Main Cover (Slide 1) */}
      <section id="section-cover">
        <InvitationCover onNavigateToNext={scrollToDetails} />
      </section>

      {/* Visual Floral Separator Line */}
      <div className="w-full flex items-center justify-center py-6 bg-gradient-to-b from-[#F6F5F2] to-[#F3F4F1] select-none text-sage-300">
        <span className="h-px w-16 bg-sage-300/40" />
        <span className="text-lg mx-3">🌸</span>
        <span className="h-px w-16 bg-sage-300/40" />
      </div>

      {/* Anchor point for the main action scrolling */}
      <div ref={detailsRef} />

      {/* 3. Parents & Sponsors Slide (Slide 2) */}
      <section id="section-sponsors" className="relative group">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
        >
          <SponsorsSec />
        </motion.div>
      </section>

      {/* Visual Floral Separator Line */}
      <div className="w-full flex items-center justify-center py-6 bg-gradient-to-b from-[#E7ECE6] to-[#E7ECE6] select-none text-sage-300">
        <span className="h-px w-16 bg-sage-300/30" />
        <span className="text-lg mx-3">🌿</span>
        <span className="h-px w-16 bg-sage-300/30" />
      </div>

      {/* 4. Wedding Party Entourage (Slides 3, 4, 5) */}
      <section id="section-entourage">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
        >
          <WeddingParty />
        </motion.div>
      </section>

      {/* Visual Floral Separator Line */}
      <div className="w-full flex items-center justify-center py-6 bg-gradient-to-b from-[#FAF9F5] to-[#FAF9F5] select-none text-sage-300">
        <span className="h-px w-16 bg-sage-300/40" />
        <span className="text-lg mx-3">✨</span>
        <span className="h-px w-16 bg-sage-300/40" />
      </div>

      {/* 5. Ceremony timelines and Program Roles (Slide 6) */}
      <section id="section-ceremony">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
        >
          <CeremonyRoles />
        </motion.div>
      </section>

      {/* Visual Floral Separator Line */}
      <div className="w-full flex items-center justify-center py-6 bg-[#FAF9F5] select-none text-sage-300">
        <span className="h-px w-16 bg-sage-300/30" />
        <span className="text-lg mx-3">🌹</span>
        <span className="h-px w-16 bg-sage-300/30" />
      </div>

      {/* 6. Details, Dress Code & Registry (Slide 7) */}
      <section id="section-details">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
        >
          <DetailsSec />
        </motion.div>
      </section>

      {/* 8. Elegant Footer */}
      <footer className="bg-sage-900 text-sage-100 py-16 px-6 relative border-t border-sage-800 overflow-hidden select-none">
        {/* Subtle background overlay */}
        <div className="absolute inset-0 bg-black/10 pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-sage-800/15 rounded-full filter blur-xl pointer-events-none" />

        <div className="max-w-4xl mx-auto flex flex-col items-center text-center gap-6 relative z-10">
          <div className="flex items-center gap-1">
            <span className="font-script text-4xl sm:text-5xl text-sage-200">Vinicius</span>
            <span className="font-script text-5xl text-sage-400 font-light italic mx-1">&</span>
            <span className="font-script text-4xl sm:text-5xl text-sage-200">Trish</span>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center gap-2 sm:gap-6 text-xs text-sage-400 font-montserrat uppercase tracking-widest mt-2">
            <span className="flex items-center gap-1.5"><Calendar className="w-4 h-4 text-[#CBB199]" /> Wednesday, August 12</span>
            <span className="hidden sm:inline text-sage-600">•</span>
            <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4 text-[#CBB199]" /> Shizuoka, Japan</span>
          </div>

          <p className="max-w-md text-sage-400 text-xs font-serif leading-relaxed italic mt-2">
            "Thank you for being part of our story, sharing our dreams, and showering us with your blessings. We love you all!"
          </p>

          <hr className="w-16 border-t border-sage-800/80 my-4" />

          <p className="text-[10px] font-montserrat text-sage-500 uppercase tracking-wider">
            © 2026 Vinicius & Trish Goyo. All Rights Reserved.
          </p>
        </div>
      </footer>

      {/* 9. Floating Background Music Melodic Loop Controller */}
      <BackgroundMusic />
    </div>
  );
}

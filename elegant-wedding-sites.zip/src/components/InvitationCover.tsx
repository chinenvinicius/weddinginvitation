/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Calendar, MapPin, Heart, ChevronDown } from 'lucide-react';
import { motion } from 'motion/react';

interface InvitationCoverProps {
  onNavigateToNext: () => void;
}

export default function InvitationCover({ onNavigateToNext }: InvitationCoverProps) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    // Target date: Wednesday, August 12, 2026
    const targetDate = new Date('August 12, 2026 16:00:00').getTime();

    const interval = setInterval(() => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference < 0) {
        clearInterval(interval);
      } else {
        const d = Math.floor(difference / (1000 * 60 * 60 * 24));
        const h = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const m = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const s = Math.floor((difference % (1000 * 60)) / 1000);
        setTimeLeft({ days: d, hours: h, minutes: m, seconds: s });
      }
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative min-h-[96vh] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-[#FAF8F5] via-[#F4F2EC] to-[#FAF8F5] overflow-hidden">
      
      {/* Delicate background image layer for watercolor paper texture & subtle organic feel */}
      <div 
        className="absolute inset-0 bg-cover bg-center pointer-events-none opacity-[0.12] mix-blend-multiply"
        style={{ backgroundImage: `url('https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&q=80&w=1600')` }}
      />

      {/* 1. Ambient Background Watercolor Splotches */}
      <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#E4ECE3]/35 rounded-full filter blur-[120px] pointer-events-none select-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[45%] h-[45%] bg-[#F3E5E6]/30 rounded-full filter blur-[100px] pointer-events-none select-none" />
      <div className="absolute top-[30%] left-[20%] w-[35%] h-[35%] bg-[#FAF2E8]/40 rounded-full filter blur-[90px] pointer-events-none select-none" />

      {/* 2. Main Card Container (The Elegant Invitation Canvas) */}
      <div className="w-full max-w-5xl bg-[#FAF9F5] rounded-[2.5rem] shadow-[0_25px_60px_-15px_rgba(71,88,72,0.12)] border border-[#EBE8DF] relative overflow-hidden p-6 sm:p-10 md:p-12">
        
        {/* Double Border Frame */}
        <div className="absolute inset-4 sm:inset-6 border border-[#D1C7BD]/45 rounded-[2rem] pointer-events-none z-10" />
        <div className="absolute inset-[1.25rem] sm:inset-[1.75rem] border border-dashed border-[#D1C7BD]/25 rounded-[1.85rem] pointer-events-none z-10" />

        {/* Vintage Gold Corner Ornaments */}
        <div className="absolute top-[2rem] left-[2rem] w-8 h-8 pointer-events-none z-20 text-[#C4B29E]/70">
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="3" className="w-full h-full">
            <path d="M5 40 L5 5 C5 5, 40 5, 40 5" strokeLinecap="round" />
            <path d="M15 30 L15 15 C15 15, 30 15, 30 15" strokeLinecap="round" />
            <circle cx="5" cy="5" r="3" fill="currentColor" />
          </svg>
        </div>
        <div className="absolute top-[2rem] right-[2rem] w-8 h-8 pointer-events-none z-20 text-[#C4B29E]/70 rotate-90">
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="3" className="w-full h-full">
            <path d="M5 40 L5 5 C5 5, 40 5, 40 5" strokeLinecap="round" />
            <path d="M15 30 L15 15 C15 15, 30 15, 30 15" strokeLinecap="round" />
            <circle cx="5" cy="5" r="3" fill="currentColor" />
          </svg>
        </div>
        <div className="absolute bottom-[2rem] left-[2rem] w-8 h-8 pointer-events-none z-20 text-[#C4B29E]/70 -rotate-90">
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="3" className="w-full h-full">
            <path d="M5 40 L5 5 C5 5, 40 5, 40 5" strokeLinecap="round" />
            <path d="M15 30 L15 15 C15 15, 30 15, 30 15" strokeLinecap="round" />
            <circle cx="5" cy="5" r="3" fill="currentColor" />
          </svg>
        </div>
        <div className="absolute bottom-[2rem] right-[2rem] w-8 h-8 pointer-events-none z-20 text-[#C4B29E]/70 rotate-180">
          <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="3" className="w-full h-full">
            <path d="M5 40 L5 5 C5 5, 40 5, 40 5" strokeLinecap="round" />
            <path d="M15 30 L15 15 C15 15, 30 15, 30 15" strokeLinecap="round" />
            <circle cx="5" cy="5" r="3" fill="currentColor" />
          </svg>
        </div>

        {/* Top Right Corner Floral Cascade (Eucalyptus + Burgundy Dahlias) */}
        <div className="absolute top-3 right-3 w-40 sm:w-64 h-40 sm:h-64 pointer-events-none z-20 opacity-90 select-none">
          <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
            {/* Eucalyptus stems */}
            <path d="M200 0 C150 20, 120 70, 160 120" stroke="#7A8B7A" strokeWidth="1.5" strokeLinecap="round" />
            <path d="M200 20 C160 40, 130 90, 180 140" stroke="#6F806F" strokeWidth="1.5" strokeLinecap="round" />
            {/* Eucalyptus leaves */}
            <circle cx="150" cy="45" r="14" fill="#8FA38F" fillOpacity="0.85" stroke="#7E927E" strokeWidth="0.5" />
            <circle cx="132" cy="72" r="16" fill="#A1B5A1" fillOpacity="0.85" stroke="#8FA38F" strokeWidth="0.5" />
            <circle cx="172" cy="85" r="15" fill="#819381" fillOpacity="0.8" stroke="#6F806F" strokeWidth="0.5" />
            <circle cx="155" cy="115" r="12" fill="#95A895" fillOpacity="0.85" stroke="#819381" strokeWidth="0.5" />
            {/* Soft background foliage */}
            <path d="M200 40 C140 30, 110 80, 130 130 Z" fill="#6E806E" fillOpacity="0.15" />
            {/* Big Burgundy Dahlia (Top-right accent) */}
            <g transform="translate(180, 25)">
              <circle cx="0" cy="0" r="18" fill="#5C0612" />
              {/* Petals layer 1 */}
              {[0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330].map((deg) => (
                <path
                  key={deg}
                  d="M0 0 C-6 -10, -10 -25, 0 -32 C10 -25, 6 -10, 0 0"
                  fill="#7D0F1D"
                  transform={`rotate(${deg})`}
                  stroke="#5C0612"
                  strokeWidth="0.5"
                />
              ))}
              {/* Petals layer 2 */}
              {[15, 45, 75, 105, 135, 165, 195, 225, 255, 285, 315, 345].map((deg) => (
                <path
                  key={deg}
                  d="M0 0 C-4 -8, -8 -20, 0 -26 C8 -20, 4 -8, 0 0"
                  fill="#9C1A2D"
                  transform={`rotate(${deg})`}
                />
              ))}
              {/* Flower Center */}
              <circle cx="0" cy="0" r="7" fill="#D4AF37" stroke="#9C1A2D" strokeWidth="1" />
              <circle cx="0" cy="0" r="4" fill="#E5C158" />
            </g>
          </svg>
        </div>

        {/* 3. Core Layout: Grid of Photos (Left) and Content (Right) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch relative z-20">
          
          {/* Left Column: Vertical Photo Collage (Exactly reproducing the 3-photo card stack) */}
          <div className="lg:col-span-5 flex flex-col justify-center items-center relative">
            <div className="w-full max-w-[360px] sm:max-w-[390px] relative flex flex-col gap-2 p-1.5 bg-[#FAF9F5]/40 rounded-[2rem]">
              
              {/* Photo 1 (Top) - Curved Top Corners */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.1 }}
                className="w-full h-[160px] sm:h-[185px] overflow-hidden rounded-t-[1.8rem] rounded-b-md shadow-sm border border-[#E5E2D6]/60 relative group"
              >
                <img 
                  src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=600" 
                  alt="Vinicius & Trish Sweet Moment" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent pointer-events-none" />
              </motion.div>

              {/* Photo 2 (Middle) - Rectangular with subtle borders */}
              <motion.div 
                initial={{ opacity: 0, y: 25 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="w-full h-[160px] sm:h-[185px] overflow-hidden rounded-md shadow-sm border border-[#E5E2D6]/60 relative group"
              >
                <img 
                  src="https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8?auto=format&fit=crop&q=80&w=600" 
                  alt="Vinicius & Trish Smiles" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent pointer-events-none" />
              </motion.div>

              {/* Photo 3 (Bottom) - Curved Bottom Corners */}
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                className="w-full h-[160px] sm:h-[185px] overflow-hidden rounded-b-[1.8rem] rounded-t-md shadow-sm border border-[#E5E2D6]/60 relative group"
              >
                <img 
                  src="https://images.unsplash.com/photo-1518199266791-5375a83190b7?auto=format&fit=crop&q=80&w=600" 
                  alt="Vinicius & Trish near the Gate" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/15 to-transparent pointer-events-none" />
              </motion.div>

              {/* Middle Floral Cluster Overlay (Nestled perfectly like the card) */}
              <div className="absolute bottom-[28%] right-[-1.5rem] w-32 h-32 pointer-events-none z-30 select-none drop-shadow-md animate-float-gentle">
                <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
                  {/* Leaves */}
                  <path d="M20 50 C5 35, 30 20, 45 35 C50 25, 70 30, 60 45" stroke="#7A8B7A" strokeWidth="1" />
                  <circle cx="28" cy="35" r="9" fill="#8FA38F" fillOpacity="0.9" stroke="#7E927E" strokeWidth="0.5" />
                  <circle cx="48" cy="40" r="11" fill="#A1B5A1" fillOpacity="0.9" stroke="#8FA38F" strokeWidth="0.5" />
                  <circle cx="34" cy="54" r="8" fill="#819381" fillOpacity="0.85" stroke="#6F806F" strokeWidth="0.5" />
                  {/* Dahlia Flower */}
                  <g transform="translate(45, 52)">
                    <circle cx="0" cy="0" r="10" fill="#4A0E17" />
                    {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
                      <path
                        key={deg}
                        d="M0 0 C-3 -5, -5 -14, 0 -18 C5 -14, 3 -5, 0 0"
                        fill="#7D0F1D"
                        transform={`rotate(${deg})`}
                      />
                    ))}
                    {[22.5, 67.5, 112.5, 157.5, 202.5, 247.5, 292.5, 337.5].map((deg) => (
                      <path
                        key={deg}
                        d="M0 0 C-2 -4, -4 -11, 0 -14 C4 -11, 2 -4, 0 0"
                        fill="#9C1A2D"
                        transform={`rotate(${deg})`}
                      />
                    ))}
                    <circle cx="0" cy="0" r="4" fill="#D4AF37" />
                    <circle cx="0" cy="0" r="2.5" fill="#E5C158" />
                  </g>
                </svg>
              </div>

            {/* Little bird / golden sparkles */}
            <div className="absolute top-[25%] left-[-1.5rem] text-[#D4C3B3] text-xl pointer-events-none select-none z-35 animate-bounce">
              ✨
            </div>
          </div>
        </div>

        {/* Right Column: Invitation Ceremony Content (Faithful reproduction of card stationery) */}
        <div className="lg:col-span-7 flex flex-col items-center justify-center text-center px-2 sm:px-4 lg:pl-6">
          
          {/* Top Intro Tag */}
          <span className="font-serif text-[11px] sm:text-xs tracking-[0.28em] text-[#8D7A6C] font-semibold uppercase select-none">
            Together with their families
          </span>

          {/* Delicate horizontal gold line ornament with a center diamond */}
          <div className="flex items-center gap-2 w-32 my-3 select-none">
            <span className="h-[0.5px] bg-[#C4B29E]/50 flex-grow" />
            <span className="text-[7px] text-[#C4B29E]">◆</span>
            <span className="h-[0.5px] bg-[#C4B29E]/50 flex-grow" />
          </div>

          {/* Exquisite Overlapping Calligraphy & Name Title */}
          <div className="relative w-full py-2 flex flex-col items-center select-none">
            <h1 className="font-script text-7xl sm:text-8xl md:text-[5.5rem] lg:text-[6.2rem] text-[#3D171A] leading-[1.05] tracking-wide filter drop-shadow-sm font-medium">
              Vinicius
            </h1>
            
            {/* Elegant overlapping giant italic gold ampersand */}
            <span className="font-serif italic font-light text-[#C5A059] text-7xl sm:text-8xl md:text-[5.5rem] -my-7 sm:-my-10 opacity-80 z-10 select-none block">
              &
            </span>

            <h1 className="font-script text-7xl sm:text-8xl md:text-[5.5rem] lg:text-[6.2rem] text-[#3D171A] leading-[1.05] tracking-wide filter drop-shadow-sm font-medium">
              Trish
            </h1>
          </div>

          {/* Invitation Call Statement */}
          <div className="flex flex-col gap-0.5 mt-2 select-none">
            <span className="font-serif text-[10px] sm:text-[11px] tracking-[0.22em] text-[#8D7A6C] uppercase">
              Joyfully invite you to
            </span>
            <span className="font-serif text-xs sm:text-sm tracking-[0.18em] text-[#5C705D] font-bold uppercase">
              Celebrate their wedding
            </span>
          </div>

          {/* Divider line */}
          <div className="w-16 h-px bg-[#E5E2D6] my-5" />
          <div className="flex flex-col items-center gap-1.5 select-none bg-white/35 px-6 py-4 rounded-2xl border border-sage-100/50">
            <span className="font-serif text-[10px] sm:text-xs tracking-[0.25em] text-[#8D7A6C] uppercase font-semibold">
              Wednesday
            </span>
            
            {/* Recreated 08 | 12 | 26 Date Grid */}
            <div className="flex items-center gap-4 text-3xl sm:text-4xl font-serif text-[#3D171A] font-light py-1.5">
              <span>08</span>
              <span className="text-[#C5A059] font-light text-2xl">|</span>
              <span>12</span>
              <span className="text-[#C5A059] font-light text-2xl">|</span>
              <span>26</span>
            </div>

            <span className="font-serif text-[10px] sm:text-xs tracking-[0.2em] text-[#8D7A6C] uppercase">
              At 4:00 PM
            </span>
          </div>

          {/* Venue & Location Block (Exactly as in Goyo scans) */}
          <div className="mt-6 flex flex-col items-center select-none">
            <h2 className="font-serif font-bold text-lg sm:text-xl text-[#5C0612] tracking-[0.16em] uppercase leading-tight">
              Aeru Kikugawa
            </h2>
            <h2 className="font-serif font-bold text-lg sm:text-xl text-[#5C0612] tracking-[0.16em] uppercase leading-tight">
              Cultural Hall
            </h2>
            <div className="mt-2.5 text-center text-[#70645A] font-montserrat text-[10px] sm:text-xs tracking-[0.12em] leading-relaxed uppercase">
              <p>2488-2 Honjo, Kikugawa</p>
              <p>Shizuoka 439-0018, Japan</p>
            </div>
          </div>

          {/* "Reception to follow" Elegant Cursive Suffix */}
          <p className="font-script text-3xl sm:text-4xl text-[#C5A059] mt-5 mb-4 select-none">
            Reception to follow
          </p>

          {/* Countdown Module (Styled exquisitely in alignment) */}
          <div className="w-full max-w-sm mt-3 bg-white/40 rounded-2xl p-3 border border-[#E5E2D6]/80 flex flex-col items-center gap-2">
            <span className="font-montserrat text-[9px] uppercase font-bold tracking-[0.18em] text-[#8D7A6C] flex items-center gap-1">
              <Heart className="w-3 h-3 fill-[#8D7A6C] animate-pulse" /> Countdown to August 12, 2026
            </span>
            <div className="flex gap-4 text-center">
              <div className="flex flex-col">
                <span className="font-serif text-xl sm:text-2xl font-medium text-[#3D171A]">{timeLeft.days}</span>
                <span className="font-montserrat text-[8px] uppercase tracking-wider text-sage-500">Days</span>
              </div>
              <span className="font-serif text-lg text-sage-400 self-center">:</span>
              <div className="flex flex-col">
                <span className="font-serif text-xl sm:text-2xl font-medium text-[#3D171A]">{String(timeLeft.hours).padStart(2, '0')}</span>
                <span className="font-montserrat text-[8px] uppercase tracking-wider text-sage-500">Hours</span>
              </div>
              <span className="font-serif text-lg text-sage-400 self-center">:</span>
              <div className="flex flex-col">
                <span className="font-serif text-xl sm:text-2xl font-medium text-[#3D171A]">{String(timeLeft.minutes).padStart(2, '0')}</span>
                <span className="font-montserrat text-[8px] uppercase tracking-wider text-sage-500">Mins</span>
              </div>
              <span className="font-serif text-lg text-sage-400 self-center">:</span>
              <div className="flex flex-col">
                <span className="font-serif text-xl sm:text-2xl font-medium text-[#3D171A]">{String(timeLeft.seconds).padStart(2, '0')}</span>
                <span className="font-montserrat text-[8px] uppercase tracking-wider text-sage-500">Secs</span>
              </div>
            </div>
          </div>

          {/* Navigation Action Button */}
          <div className="mt-6">
            <button
              type="button"
              onClick={onNavigateToNext}
              className="group flex items-center gap-2 bg-[#8D7A6C] text-white px-5 py-2.5 rounded-full shadow-md hover:bg-[#70645A] transition-all font-montserrat text-[10px] tracking-widest font-semibold hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 cursor-pointer uppercase"
            >
              View Full Details
              <ChevronDown className="w-3.5 h-3.5 group-hover:translate-y-0.5 transition-transform" />
            </button>
          </div>

        </div>

      </div>
    </div>
  </div>
);
}


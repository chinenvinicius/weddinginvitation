/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Gift, Paintbrush } from 'lucide-react';
import { dressCodeColorsGown, dressCodeColorsSuit } from '../data';

export default function DetailsSec() {
  return (
    <div className="relative min-h-[92vh] flex flex-col items-center justify-center py-10 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-[#FAF9F5] to-[#F1F2ED] overflow-hidden">
      
      {/* Decorative vector arches */}
      <div className="absolute top-0 inset-x-0 h-48 bg-gradient-to-b from-white to-transparent pointer-events-none" />

      <div className="w-full max-w-5xl bg-white/70 backdrop-blur-md rounded-[2.5rem] border border-white/80 p-5 sm:p-10 lg:p-12 shadow-xl relative z-10">
        
        {/* Title */}
        <div className="text-center mb-10">
          <span className="text-xs uppercase tracking-[0.3em] font-montserrat font-semibold text-sage-500">ATTENDING DETAILS</span>
          <h2 className="font-serif text-3xl sm:text-4xl text-sage-800 font-bold tracking-wide mt-1">Wedding Guidelines & Details</h2>
          <div className="flex items-center justify-center gap-2 mt-3">
            <span className="h-px w-6 bg-sage-300" />
            <Paintbrush className="w-3.5 h-3.5 text-sage-400 fill-sage-100" />
            <span className="h-px w-6 bg-sage-300" />
          </div>
        </div>

        {/* Core Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          
          {/* Left Block (Lg: Col-7) - Clean Dress Code Swatches */}
          <div className="lg:col-span-7 bg-white/45 p-6 sm:p-8 rounded-3xl border border-sage-100/60 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-sage-100/50 pb-4 mb-6 select-none">
                <div>
                  <h3 className="font-montserrat text-xs tracking-widest text-[#8D7A6C] font-bold uppercase">
                    Attire & Dress Code
                  </h3>
                  <p className="text-[10px] text-sage-500 font-montserrat mt-0.5">Formal / Semi-Formal Color Palette</p>
                </div>
                <span className="text-sm">🧥👗</span>
              </div>

              <p className="font-serif text-sage-700 text-sm sm:text-base leading-relaxed mb-8 text-center sm:text-left">
                "We kindly encourage our guests to wear formal or semi-formal attire with these beautiful warm colors on our special day."
              </p>

              {/* Color selectors */}
              <div className="space-y-8">
                {/* Sage Green Gown Palette */}
                <div className="space-y-4">
                  <span className="font-montserrat text-[10px] tracking-widest uppercase font-bold text-sage-600 flex items-center gap-1.5">
                    🌿 Sage Foliage Palette
                  </span>
                  
                  <div className="grid grid-cols-5 gap-4">
                    {dressCodeColorsGown.map((color) => (
                      <div key={color.hex} className="flex flex-col items-center gap-2">
                        <div
                          style={{ backgroundColor: color.hex }}
                          className="w-10 h-10 sm:w-12 sm:h-12 rounded-full shadow-inner border border-sage-200/40 relative"
                          title={color.name}
                        />
                        <span className="font-montserrat text-[9px] text-sage-500 tracking-wider text-center uppercase font-medium">
                          {color.name}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Burgundy Suit Palette */}
                <div className="space-y-4 pt-4 border-t border-sage-100/45">
                  <span className="font-montserrat text-[10px] tracking-widest uppercase font-bold text-sage-600 flex items-center gap-1.5">
                    🍷 Velvet Wine Palette
                  </span>
                  
                  <div className="grid grid-cols-5 gap-4">
                    {dressCodeColorsSuit.map((color) => (
                      <div key={color.hex} className="flex flex-col items-center gap-2">
                        <div
                          style={{ backgroundColor: color.hex }}
                          className="w-10 h-10 sm:w-12 sm:h-12 rounded-full shadow-inner border border-sage-200/40 relative"
                          title={color.name}
                        />
                        <span className="font-montserrat text-[9px] text-sage-500 tracking-wider text-center uppercase font-medium">
                          {color.name}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Block (Lg: Col-5) - Notice on Gifts */}
          <div className="lg:col-span-5 bg-white/45 p-6 sm:p-8 rounded-3xl border border-sage-100/60 shadow-sm flex flex-col justify-center items-center text-center relative overflow-hidden min-h-[300px]">
            <div className="absolute top-0 inset-x-0 h-1 bg-[#CBB199]" />
            
            <div className="flex flex-col items-center justify-center py-4">
              <div className="w-16 h-16 rounded-full bg-[#CBB199]/10 flex items-center justify-center text-[#A38E7E] mb-5 border border-[#CBB199]/20 shadow-inner">
                <Gift className="w-7 h-7" />
              </div>

              <h3 className="font-montserrat text-xs tracking-widest text-[#8D7A6C] font-bold uppercase mb-4 select-none">
                A Notice on Gifts
              </h3>

              <div className="space-y-4 max-w-sm">
                <p className="font-serif text-sage-800 text-base sm:text-lg leading-relaxed">
                  "Your presence on our wedding is enough."
                </p>
                <p className="font-serif text-sage-600/90 text-sm sm:text-base leading-relaxed italic">
                  "However, if you wish to give us something, monetary gift will be greatly appreciated."
                </p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ShieldCheck, Award, Star, Mic, Music2, MapPin, Sparkles } from 'lucide-react';
import { programRoles } from '../data';

export default function CeremonyRoles() {
  return (
    <div className="relative min-h-[92vh] flex flex-col items-center justify-center py-10 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-[#F1F2ED] to-[#FAF9F5] overflow-hidden">
      
      {/* Decorative SVG floral line art */}
      <div className="absolute left-1/2 -translate-x-1/2 top-4 w-96 h-96 pointer-events-none opacity-[0.03] select-none">
        <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full text-sage-950">
          <circle cx="50" cy="50" r="45" stroke="currentColor" strokeWidth="0.5" />
          <path d="M50 5 Q 50 50, 95 50" stroke="currentColor" strokeWidth="0.5" />
          <path d="M50 5 Q 50 50, 5 50" stroke="currentColor" strokeWidth="0.5" />
        </svg>
      </div>

      <div className="w-full max-w-4xl bg-white/75 backdrop-blur-md rounded-[2.5rem] border border-white/90 p-5 sm:p-10 shadow-xl relative z-10">
        
        {/* Title */}
        <div className="text-center mb-10">
          <span className="text-xs uppercase tracking-[0.3em] font-montserrat font-semibold text-sage-500">THE PROGRAM DIRECTORS</span>
          <h2 className="font-serif text-3xl sm:text-4xl text-sage-800 font-bold tracking-wide mt-1">Ceremony & Program Roles</h2>
          <div className="flex items-center justify-center gap-2 mt-3">
            <span className="h-px w-6 bg-sage-300" />
            <Award className="w-3.5 h-3.5 text-sage-400 fill-sage-100" />
            <span className="h-px w-6 bg-sage-300" />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          
          {/* Core Program Directors */}
          <div className="bg-white/40 p-6 sm:p-8 rounded-2xl border border-sage-100/60 shadow-sm relative overflow-hidden flex flex-col justify-between">
            <div className="absolute top-0 inset-x-0 h-[3px] bg-[#CBB199]" />
            <div>
              <h3 className="font-montserrat text-xs tracking-widest text-[#8D7A6C] font-bold uppercase mb-6 select-none">
                Core Program Directors
              </h3>

              <div className="space-y-4">
                {/* Officiating Minister */}
                <div className="flex items-start gap-3">
                  <span className="text-lg mt-0.5">✝️</span>
                  <div>
                    <span className="font-montserrat text-[9px] uppercase tracking-wider text-sage-505 font-bold">Officiating Minister</span>
                    <p className="font-serif italic text-lg text-sage-850 leading-tight mt-0.5">{programRoles.officiatingMinister}</p>
                  </div>
                </div>

                {/* Emcee */}
                <div className="flex items-start gap-3 pt-3 border-t border-sage-100/40">
                  <span className="text-lg mt-0.5">🎤</span>
                  <div>
                    <span className="font-montserrat text-[9px] uppercase tracking-wider text-sage-505 font-bold">Emcee</span>
                    <p className="font-serif italic text-lg text-sage-850 leading-tight mt-0.5">{programRoles.emcee}</p>
                  </div>
                </div>

                {/* Singer */}
                <div className="flex items-start gap-3 pt-3 border-t border-sage-100/40">
                  <span className="text-lg mt-0.5">🎵</span>
                  <div>
                    <span className="font-montserrat text-[9px] uppercase tracking-wider text-sage-505 font-bold">Singer</span>
                    <p className="font-serif italic text-lg text-sage-850 leading-tight mt-0.5">{programRoles.singer}</p>
                  </div>
                </div>

                {/* Program Coordinator */}
                <div className="flex items-start gap-3 pt-3 border-t border-sage-100/40">
                  <span className="text-lg mt-0.5">📋</span>
                  <div>
                    <span className="font-montserrat text-[9px] uppercase tracking-wider text-sage-505 font-bold">Program Coordinator</span>
                    <p className="font-serif italic text-lg text-sage-850 leading-tight mt-0.5">{programRoles.programCoordinator}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Usherettes Board */}
          <div className="bg-white/40 p-6 sm:p-8 rounded-2xl border border-sage-100/60 shadow-sm relative overflow-hidden flex flex-col">
            <div className="absolute top-0 inset-x-0 h-[3px] bg-sage-500/50" />
            <div>
              <h3 className="font-montserrat text-xs tracking-widest text-sage-700 font-bold uppercase mb-6 flex items-center gap-1.5 select-none">
                <span>🌸</span> Usherettes
              </h3>
              <div className="space-y-4">
                {programRoles.usherettes.map((name, i) => (
                  <div key={i} className="flex items-center gap-4 py-1 border-b border-sage-100/20 last:border-0">
                    <span className="font-montserrat text-xs text-sage-400 font-semibold w-6">0{i + 1}</span>
                    <p className="font-serif italic text-lg text-sage-850 leading-none">{name}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
        </div>

      </div>
    </div>
  );
}

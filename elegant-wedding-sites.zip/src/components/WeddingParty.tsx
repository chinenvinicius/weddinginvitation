/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Sparkles, Star, MessageSquare, Heart, ShieldAlert, Award } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { weddingParty, childEntourageAndBearers } from '../data';

export default function WeddingParty() {
  const [activeTab, setActiveTab] = useState<'adults' | 'children_bearers'>('adults');

  return (
    <div className="relative min-h-[92vh] flex flex-col items-center justify-center py-10 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-[#E7ECE6] to-[#F1F2ED] overflow-hidden">
      
      {/* Background floral flourishes */}
      <div className="absolute right-0 top-1/4 w-32 sm:w-56 h-32 sm:h-56 select-none opacity-20 pointer-events-none">
        <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full text-sage-400 rotate-90">
          <path d="M50 0 C70 30, 90 20, 100 50 C80 80, 50 100, 30 70 Z" fill="currentColor" opacity="0.3"/>
        </svg>
      </div>

      <div className="w-full max-w-5xl bg-white/70 backdrop-blur-md rounded-[2.5rem] border border-white/80 p-5 sm:p-10 shadow-xl relative z-10">
        
        {/* Title */}
        <div className="text-center mb-8">
          <span className="text-xs uppercase tracking-[0.3em] font-montserrat font-semibold text-sage-500">WITNESSES OF LOVE</span>
          <h2 className="font-serif text-3xl sm:text-4xl text-sage-800 font-bold tracking-wide mt-1">The Wedding Entourage</h2>
          <p className="font-serif text-sage-600/90 text-sm italic mt-1.5">
            "An entourage of souls, helping guide their path of eternity."
          </p>
          <div className="flex items-center justify-center gap-2 mt-3">
            <span className="h-px w-6 bg-sage-300" />
            <Sparkles className="w-3.5 h-3.5 text-sage-400 fill-sage-100" />
            <span className="h-px w-6 bg-sage-300" />
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex justify-center mb-8">
          <div className="flex p-1.5 bg-sage-100/55 rounded-full border border-sage-200/40">
            <button
              type="button"
              onClick={() => setActiveTab('adults')}
              className={`px-5 py-2 rounded-full text-xs font-montserrat tracking-widest font-semibold transition-all duration-300 cursor-pointer ${
                activeTab === 'adults'
                  ? 'bg-sage-600 text-white shadow-sm'
                  : 'text-sage-600 hover:text-sage-800'
              }`}
            >
              BRIDESMAIDS & GROOMSMEN
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('children_bearers')}
              className={`px-5 py-2 rounded-full text-xs font-montserrat tracking-widest font-semibold transition-all duration-300 cursor-pointer ${
                activeTab === 'children_bearers'
                  ? 'bg-sage-600 text-white shadow-sm'
                  : 'text-sage-600 hover:text-sage-800'
              }`}
            >
              BEARERS & LITTLE TREASURES
            </button>
          </div>
        </div>

        {/* Tab Content Panels with Micro-Animations */}
        <AnimatePresence mode="wait">
          {activeTab === 'adults' ? (
            <motion.div
              key="adults"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {/* Bridesmaids Grid */}
              <div className="bg-white/40 p-6 rounded-2xl border border-sage-100 flex flex-col md:col-span-1">
                <div className="flex items-center gap-2 pb-4 mb-4 border-b border-sage-100 select-none">
                  <span className="text-xl">🌸</span>
                  <div>
                    <h3 className="font-montserrat text-xs tracking-wider font-bold text-sage-800 uppercase">Bridesmaid</h3>
                    <p className="text-[10px] text-sage-500 font-montserrat">Standing with the Bride</p>
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  {weddingParty.bridesmaids.map((name, idx) => (
                    <div key={idx} className="flex items-center gap-3 group">
                      <span className="font-montserrat text-xs text-sage-400 font-medium">0{idx + 1}</span>
                      <span className="font-serif italic text-base sm:text-lg text-sage-850 leading-none group-hover:translate-x-1 transition-all">
                        {name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Groomsmen Grid */}
              <div className="bg-white/40 p-6 rounded-2xl border border-sage-100 flex flex-col md:col-span-1">
                <div className="flex items-center gap-2 pb-4 mb-4 border-b border-sage-100 select-none">
                  <span className="text-xl">🎩</span>
                  <div>
                    <h3 className="font-montserrat text-xs tracking-wider font-bold text-sage-800 uppercase">Groomsmen</h3>
                    <p className="text-[10px] text-sage-500 font-montserrat">Standing with the Groom</p>
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  {weddingParty.groomsmen.map((name, idx) => (
                    <div key={idx} className="flex items-center gap-3 group">
                      <span className="font-montserrat text-xs text-sage-400 font-medium">0{idx + 1}</span>
                      <span className="font-serif italic text-base sm:text-lg text-sage-850 leading-none group-hover:translate-x-1 transition-all">
                        {name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Flower Maiden Grid */}
              <div className="bg-white/40 p-6 rounded-2xl border border-sage-100 flex flex-col md:col-span-2 lg:col-span-1">
                <div className="flex items-center gap-2 pb-4 mb-4 border-b border-sage-100 select-none">
                  <span className="text-xl">💐</span>
                  <div>
                    <h3 className="font-montserrat text-xs tracking-wider font-bold text-sage-850 uppercase">Flower Maiden</h3>
                    <p className="text-[10px] text-sage-500 font-montserrat">Graceful blossoms of youth</p>
                  </div>
                </div>
                <div className="flex flex-col gap-3">
                  {weddingParty.flowerMaidens.map((name, idx) => (
                    <div key={idx} className="flex items-center gap-3 group">
                      <span className="font-montserrat text-xs text-sage-400 font-medium">0{idx + 1}</span>
                      <span className="font-serif italic text-base sm:text-lg text-sage-850 leading-none group-hover:translate-x-1 transition-all">
                        {name}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="children"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="space-y-8"
            >
              {/* Couple Leaders (Little Bride, Little Groom, Candle, Honor, Bearers) */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                
                {/* Little Groom & Bride */}
                <div className="bg-white/40 p-5 rounded-2xl border border-sage-100/80 flex flex-col items-center text-center">
                  <span className="text-lg mb-2">👧🏻👦🏻</span>
                  <span className="font-montserrat text-[10px] tracking-widest text-sage-500 uppercase font-bold">Little Bride & Groom</span>
                  <div className="mt-2 space-y-1">
                    <p className="font-serif italic text-lg text-sage-850">{childEntourageAndBearers.littleBride}</p>
                    <p className="text-[10px] text-sage-400 font-montserrat">and</p>
                    <p className="font-serif italic text-lg text-sage-850">{childEntourageAndBearers.littleGroom}</p>
                  </div>
                </div>

                {/* Bearers */}
                <div className="bg-white/40 p-5 rounded-2xl border border-sage-100/80 flex flex-col items-center text-center">
                  <span className="text-lg mb-2">💍📖</span>
                  <span className="font-montserrat text-[10px] tracking-widest text-sage-500 uppercase font-bold">Sacred Bearers</span>
                  <div className="mt-2 space-y-3">
                    <div>
                      <p className="font-serif italic text-lg text-sage-850">{childEntourageAndBearers.ringBearer}</p>
                      <p className="text-[9px] text-sage-400 font-montserrat uppercase tracking-wider">Ring Bearer</p>
                    </div>
                    <div>
                      <p className="font-serif italic text-lg text-sage-850">{childEntourageAndBearers.bibleBearer}</p>
                      <p className="text-[9px] text-sage-400 font-montserrat uppercase tracking-wider">Bible Bearer</p>
                    </div>
                  </div>
                </div>

                {/* Banner Bearers */}
                <div className="bg-white/40 p-5 rounded-2xl border border-sage-100/80 flex flex-col items-center text-center">
                  <span className="text-lg mb-2">🚩</span>
                  <span className="font-montserrat text-[10px] tracking-widest text-sage-500 uppercase font-bold">Banner Bearers</span>
                  <div className="mt-2 space-y-2">
                    {childEntourageAndBearers.bannerBearers.map((name, i) => (
                      <p key={i} className="font-serif italic text-lg text-sage-850">
                        {name}
                      </p>
                    ))}
                  </div>
                </div>

                {/* Candle Lighter */}
                <div className="bg-white/40 p-5 rounded-2xl border border-sage-100/80 flex flex-col items-center text-center">
                  <span className="text-lg mb-2">🕯️</span>
                  <span className="font-montserrat text-[10px] tracking-widest text-sage-500 uppercase font-bold">Candle Lighter</span>
                  <div className="mt-2 flex flex-col justify-center h-full pb-2">
                    <p className="font-serif italic text-lg text-sage-850">
                      {childEntourageAndBearers.candleLighters}
                    </p>
                    <p className="text-[9px] text-sage-400 font-montserrat uppercase tracking-wider mt-1">Light of Togetherness</p>
                  </div>
                </div>

              </div>

              {/* Flower Girls & Escorts */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                {/* Flower Girls */}
                <div className="bg-white/40 p-6 rounded-2xl border border-sage-100/80 flex flex-col">
                  <div className="flex items-center gap-2 pb-4 mb-4 border-b border-sage-100 select-none">
                    <span className="text-lg">🌸</span>
                    <span className="font-montserrat text-xs tracking-wider font-bold text-sage-800 uppercase">Flower Girls</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {childEntourageAndBearers.flowerGirls.map((name, idx) => (
                      <div key={idx} className="flex items-center gap-2.5">
                        <span className="font-montserrat text-[10px] text-sage-400">👧 {idx + 1}</span>
                        <span className="font-serif italic text-lg text-sage-850">
                          {name}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Escorts */}
                <div className="bg-white/40 p-6 rounded-2xl border border-sage-100/80 flex flex-col">
                  <div className="flex items-center gap-2 pb-4 mb-4 border-b border-sage-100 select-none">
                    <span className="text-lg">👦🏼</span>
                    <span className="font-montserrat text-xs tracking-wider font-bold text-sage-800 uppercase">Escorts</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {childEntourageAndBearers.escorts.map((name, idx) => (
                      <div key={idx} className="flex items-center gap-2.5">
                        <span className="font-montserrat text-[10px] text-sage-400">👦 {idx + 1}</span>
                        <span className="font-serif italic text-lg text-sage-850">
                          {name}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
